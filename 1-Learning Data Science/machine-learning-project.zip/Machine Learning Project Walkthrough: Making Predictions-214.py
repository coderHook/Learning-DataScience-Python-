## 1. Recap ##

import pandas as pd

loans = pd.read_csv("cleaned_loans_2007.csv")

print(loans.info())

## 3. Picking an error metric ##

import pandas as pd

tn = loans[(loans['loan_status'] == 0) & (predictions == 0)].shape[0]
tp = loans[(loans['loan_status'] == 1) & (predictions == 1)].shape[0]
fn = loans[(loans['loan_status'] == 1) & (predictions == 0)].shape[0]
fp = loans[(loans['loan_status'] == 0) & (predictions == 1)].shape[0]




## 5. Class imbalance ##

import pandas as pd
import numpy

# Predict that all loans will be paid off on time.
predictions = pd.Series(numpy.ones(loans.shape[0]))

# Let's do the tp, fp, tn, fn again
tn = loans[(loans['loan_status'] == 0) & (predictions == 0)].shape[0]
tp = loans[(loans['loan_status'] == 1) & (predictions == 1)].shape[0]
fn = loans[(loans['loan_status'] == 1) & (predictions == 0)].shape[0]
fp = loans[(loans['loan_status'] == 0) & (predictions == 1)].shape[0]

fpr = fp / (fp + tn)
tpr = tp / (tp + fn)

## 6. Logistic Regression ##

from sklearn.linear_model import LogisticRegression
lr = LogisticRegression()

features = loans.columns
features = features.drop('loan_status')

target = loans['loan_status']

lr.fit(loans[features], target)
predictions = lr.predict(loans[features])

## 7. Cross Validation ##

from sklearn.linear_model import LogisticRegression
from sklearn.cross_validation import cross_val_predict, KFold
lr = LogisticRegression()
kf = KFold(features.shape[0], random_state=1)

predictions = cross_val_predict(lr, features, target, cv=kf)

predictions = pd.Series(predictions)

tn = loans[(loans['loan_status'] == 0) & (predictions == 0)].shape[0]
tp = loans[(loans['loan_status'] == 1) & (predictions == 1)].shape[0]
fn = loans[(loans['loan_status'] == 1) & (predictions == 0)].shape[0]
fp = loans[(loans['loan_status'] == 0) & (predictions == 1)].shape[0]

tpr = tp / (tp + fn)
fpr = fp / (fp + tn)

## 9. Penalizing the classifier ##

from sklearn.linear_model import LogisticRegression
from sklearn.cross_validation import cross_val_predict

lr = LogisticRegression(class_weight = 'balanced')

kf = KFold(features.shape[0], random_state=1)

predictions = cross_val_predict(lr, features, target, cv=kf)

tn = loans[(loans['loan_status'] == 0) & (predictions == 0)].shape[0]
tp = loans[(loans['loan_status'] == 1) & (predictions == 1)].shape[0]
fn = loans[(loans['loan_status'] == 1) & (predictions == 0)].shape[0]
fp = loans[(loans['loan_status'] == 0) & (predictions == 1)].shape[0]

tpr = tp / (tp + fn)
fpr = fp / (fp + tn)

print(tpr)
print(fpr)

## 10. Manual penalties ##

from sklearn.linear_model import LogisticRegression
from sklearn.cross_validation import cross_val_predict

penalty = {
    0: 10,
    1: 1
}

lr = LogisticRegression(class_weight = penalty)

kf = KFold(features.shape[0], random_state=1)

predictions = cross_val_predict(lr, features, target, cv=kf)

tn = loans[(loans['loan_status'] == 0) & (predictions == 0)].shape[0]
tp = loans[(loans['loan_status'] == 1) & (predictions == 1)].shape[0]
fn = loans[(loans['loan_status'] == 1) & (predictions == 0)].shape[0]
fp = loans[(loans['loan_status'] == 0) & (predictions == 1)].shape[0]

tpr = tp / (tp + fn)
fpr = fp / (fp + tn)

print(tpr)
print(fpr)

## 11. Random forests ##

from sklearn.ensemble import RandomForestClassifier
from sklearn.cross_validation import cross_val_predict

randome_forest = RandomForestClassifier(random_state = 1, class_weight='balanced')

kf = KFold(features.shape[0], random_state=1)

predictions = cross_val_predict(randome_forest, features, target, cv=kf)

tn = loans[(loans['loan_status'] == 0) & (predictions == 0)].shape[0]
tp = loans[(loans['loan_status'] == 1) & (predictions == 1)].shape[0]
fn = loans[(loans['loan_status'] == 1) & (predictions == 0)].shape[0]
fp = loans[(loans['loan_status'] == 0) & (predictions == 1)].shape[0]

tpr = tp / (tp + fn)
fpr = fp / (fp + tn)

print(tpr)
print(fpr)