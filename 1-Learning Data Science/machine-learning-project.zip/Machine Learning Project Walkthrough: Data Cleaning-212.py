## 3. Reading in to Pandas ##

import pandas as pd

loans_2007 = pd.read_csv("loans_2007.csv")

print(loans_2007.head())
print(len(loans_2007.columns))




## 5. First group of columns ##

loans_2007 = loans_2007.drop('id', axis=1)
loans_2007 = loans_2007.drop('member_id', axis=1)
loans_2007 = loans_2007.drop('funded_amnt', axis=1)
loans_2007 = loans_2007.drop('funded_amnt_inv', axis=1)
loans_2007 = loans_2007.drop('grade', axis=1)
loans_2007 = loans_2007.drop('sub_grade', axis=1)
loans_2007 = loans_2007.drop('emp_title', axis=1)
loans_2007 = loans_2007.drop('issue_d', axis=1)










## 7. Second group of features ##

cols2_todrop = ['zip_code', 'out_prncp', 'out_prncp_inv', 'total_pymnt', 'total_pymnt_inv', 'total_rec_prncp']
loans_2007 = loans_2007.drop(cols2_todrop, axis=1)

## 9. Third group of features ##

cols3_todrop = ['total_rec_int', 'total_rec_late_fee', 'recoveries', 'collection_recovery_fee', 'last_pymnt_d', 'last_pymnt_amnt']

loans_2007 = loans_2007.drop(cols3_todrop, axis=1)

print(loans_2007.head())
print(len(loans_2007.columns))

## 10. Target column ##

unique_values = loans_2007['loan_status'].value_counts()

print(unique_values)

## 12. Binary classification ##

loans_2007 = loans_2007[(loans_2007['loan_status'] == 'Fully Paid') | (loans_2007['loan_status'] == 'Charged Off')]

loans_2007 = loans_2007.replace('Fully Paid', 1)
loans_2007 = loans_2007.replace('Charged Off', 0)

print(loans_2007)

## 13. Removing single value columns ##

drop_columns = []

for n in loans_2007.columns:
    loans_2007[n] = loans_2007[n].dropna(axis = 0)
    length = len(loans_2007[n].unique())
    
    if length == 1:
        drop_columns.append(n)

loans_2007 = loans_2007.drop(drop_columns, axis = 1)

print(drop_columns)

# -----------------------------------------------

orig_columns = loans_2007.columns
drop_columns = []
for col in orig_columns:
    col_series = loans_2007[col].dropna().unique()
    if len(col_series) == 1:
        drop_columns.append(col)
loans_2007 = loans_2007.drop(drop_columns, axis=1)
print(drop_columns)