## 1. Data munging ##

/home/dq$ ls -l

## 2. Data exploration ##

/home/dq$ head 10 Hud_20*.csv