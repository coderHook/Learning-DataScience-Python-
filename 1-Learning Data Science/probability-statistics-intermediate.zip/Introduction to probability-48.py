## 1. Probability basics ##

# Print the first two rows of the data.
print(flags[:2])

most_bars_country = flags.sort_values(by=["bars"], ascending=False).iloc[0]['name']
highest_population_country = flags.sort_values(by=["population"], ascending=False).iloc[0]['name']

## 2. Calculating probability ##

total_countries = flags.shape[0]

# Probability is equal to posible outcomes / all posibilities
test = len(flags[flags['orange']>0])
orange_probability = len(flags[flags['orange'] > 0]) / total_countries
stripe_probability = len(flags[flags['stripes'] > 1]) / total_countries

## 3. Conjunctive probabilities ##

five_heads = .5 ** 5

ten_heads = .5 ** 10
hundred_heads = .5 ** 100

## 4. Dependent probabilities ##

# Remember that whether a flag has red in it or not is in the `red` column.

three_red = len(flags[flags['red'] == 1]) / len(flags['red']) * (len(flags[flags['red'] == 1]) -1 ) / (len(flags['red']) - 1) * (len(flags[flags['red'] == 1])-2) / (len(flags['red']) - 2)

## 5. Disjunctive probability ##

start = 1
end = 18000

def count_evenly_divisible(start, end, div):
    count = 0;
    for i in range(start, end+1):
        if(i%div) == 0:
            count += 1
    return count
hundred_prob = count_evenly_divisible(start, end, 100) / end

seventy_prob = count_evenly_divisible(start, end, 70) / end

## 6. Disjunctive dependent probabilities ##

stripes_or_bars = len(flags[(flags['bars'] >= 1) | (flags['stripes'] >= 1)]) / len(flags)
red_or_orange = len(flags[(flags['orange'] == 1) | (flags['red'] == 1)]) / len(flags)


## 7. Disjunctive probabilities with multiple conditions ##

heads_or = 1-(1/2*1/2*1/2)
