## 2. Calculating expected values ##

males_over50k = 0.669 * 0.241 * 32561
males_under50k = 0.669 * 0.759 * 32561
females_over50k = 0.331 * 0.241 * 32561
females_under50k = 0.331 * 0.759 * 32561

## 3. Calculating chi-squared ##

male_over50k_diff = (6662 - 5249.8) ** 2 / 5249.8
male_under50k_diff = (15128 - 16533.5) ** 2 / 16533.5
female_over50k_diff = (1179 - 2597.4) ** 2 / 2597.4
female_under50k_diff = (9592 - 8180.3) ** 2 / 8180.3

chisq_gender_income = male_over50k_diff + male_under50k_diff + female_over50k_diff + female_under50k_diff

## 4. Finding statistical significance ##

from scipy.stats import chisquare


expected = [5249.8, 2597.4, 16533.5, 8180.3]
observed = [6662, 1179, 15128, 9592]

chisquare_value, pvalue_gender_income = chisquare(observed, expected)

## 5. Cross tables ##

import pandas

table = pandas.crosstab(income["sex"], [income["race"]])

print(table)

## 6. Finding expected values ##

import numpy as np
from scipy.stats import chi2_contingency
import pandas as pd

chisq_value, pvalue_gender_race, df, expected = chi2_contingency(pd.crosstab(income["sex"], [income["race"]]))