## 2. Calculating differences ##

female_diff = (10771 - 16280.5) / 16280.5
male_diff = (21790 - 16280.5) / 16280.5

## 3. Updating the formula ##

female_diff = (10771 - 16280.5) **2 / 16280.5
male_diff = (21790 - 16280.5)**2 / 16280.5

gender_chisq = female_diff + male_diff

## 4. Generating a distribution ##

chi_squared_values = []

for n in range(1000):
    rand_num = numpy.random.random(32561)
    
    rand_num[rand_num < 0.5] = 0
    rand_num[rand_num >= 0.5] = 1
    
    male_freq = len(rand_num[rand_num == 0])
    female_freq = len(rand_num[rand_num == 1])
    
    male_diff = (male_freq - 16280.5) ** 2 / 16280.5
    female_diff = (female_freq - 16280.5) ** 2 / 16280.5
    
    
    chi_squared_values.append(male_diff + female_diff)
 

plt.hist(chi_squared_values)
plt.show()

## 6. Smaller samples ##

fem_obs = 107.71
mal_obs = 217.90

fem_exp = 162.805
mal_exp = 162.805

female_diff = (fem_obs - fem_exp) **2 / fem_exp
male_diff = (mal_obs - mal_exp) ** 2 / mal_exp

gender_chisq = male_diff + female_diff

## 7. Sampling distribution equality ##

chi_squared_values = []

for i in range(1000):
    sequence = numpy.random.random_sample(300, )
    sequence[sequence < .5] = 0
    sequence[sequence >= .5] = 1
    
    male_freq = len(sequence[sequence == 0])
    female_freq = len(sequence[sequence == 1])
    
    male_diff = (male_freq - 150) ** 2 / 150
    female_diff = (female_freq - 150) ** 2 / 150
    
    chi_squared_values.append(male_diff + female_diff)
 
plt.hist(chi_squared_values)
plt.show()

## 9. Increasing degrees of freedom ##

white_diff = (27816 - 26146.5) **2 / 26146.5
black_diff = (3124 - 3939.9) **2 / 3939.9
asian_diff = (1039 - 944.3) ** 2 / 944.3
ameri_diff = (311 - 260.5) ** 2 / 260.5
other_diff = (271 - 1269.8) ** 2 / 1269.8

diff_list = [white_diff, black_diff, asian_diff, ameri_diff, other_diff]

race_chisq = sum(diff_list)


## 10. Using SciPy ##

from scipy.stats import chisquare
import numpy as np

observed = [27816, 3124, 1039, 311, 271]
expected = [26146.5, 3939.9, 944.3, 260.5, 1269.8]

chisquare_race, race_pvalue = chisquare(observed, expected)