## 1. Why Learn Calculus? ##

import numpy as np
import matplotlib.pyplot as plt

x= numpy.linspace(0, 1, 301)

y = -(x**2) + 3*x-1

plt.plot(x,y)