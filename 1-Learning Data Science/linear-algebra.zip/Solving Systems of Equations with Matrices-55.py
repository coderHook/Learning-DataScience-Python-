## 2. Systems of Equations as Matrices ##

import numpy as np

# Set the dtype to float to do float math with the numbers
matrix = np.asarray([
    [2, 1, 25],
    [3, 2, 40]  
], dtype=np.float32)

matrix_x2 = matrix[0] *2
matrix_sec_min_first = matrix[0] - matrix[1]
matrix_min3x = matrix[1] - 3*matrix[0]
matrix_div2 = matrix[1]/2

matrix[0] *= 2
matrix[0] -= matrix[1]
matrix[1] -= 3*matrix[0]
matrix[1] /= 2

print(matrix)

## 4. Solving More Complex Equations ##

import numpy as np

matrix = np.asarray([
    [1, 2, 0, 7],
    [0, 3, 3, 11],
    [1, 2, 2, 11]
], dtype=np.float32)

matrix[2] -= matrix[0]
matrix[2] /= 2
matrix[1] -= (matrix[2] * 3)
matrix[0] *= 3
matrix[1] *= 2
matrix[0] -= matrix[1]
matrix[0] /=3
matrix[1] /= 6

print(matrix)

## 5. Putting a Matrix into Echelon Form ##

matrix = np.asarray([
    [0, 0, 0, 7],
    [0, 0, 1, 11],
    [1, 2, 2, 11],
    [0, 5, 5, 1]
], dtype=np.float32)

# Swap the first and the third rows; first swap
matrix[[0,2]] = matrix[[2,0]]
matrix[[1,3]] = matrix[[3, 1]]
matrix[[2,3]] = matrix[[3, 2]]


matrix

## 7. Inconsistent Systems are Unsolvable ##

A = np.asarray([
    [10, 5, 20, 60],
    [3, 1, 0, 11],
    [8, 2, 2, 30],
    [0, 4, 5, 13]
], dtype=np.float32)

B = np.asarray([
    [5, -1, 3, 14],
    [0, 1, 2, 8],
    [0, -2, 5, 1],
    [0, 0, 6, 6]
], dtype=np.float32)

B_consistent = False
A_consistent = True

## 8. Complex Systems Can Have Infinite Solutions ##

A = np.asarray([
        [2, 4, 8, 20],
        [4, 8, 16, 40],
        [20, 5, 5, 10]
], dtype=np.float32)

B = np.asarray([
        [1, 1, 1, 4],
        [3, -2, 5, 8],
        [8, -4, 5, 10]
        ], dtype=np.float32)

A_infinite = True
# We can see A[1] is a combination os 2*A[0] so it will gave us a one level of freedom.
B_infinite = False