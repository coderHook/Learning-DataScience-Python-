## 1. Introduction ##

import numpy as np
import pandas as pd

dc_listings = pd.read_csv("dc_airbnb.csv")
stripped_commas = dc_listings['price'].str.replace(',', '')
stripped_dollars = stripped_commas.str.replace('$', '')
dc_listings['price'] = stripped_dollars.astype('float')


shuffled_index = np.random.permutation(dc_listings.index)

dc_listings = dc_listings.reindex(shuffled_index)

split_one = dc_listings.iloc[0:1862]
split_two = dc_listings.iloc[1862:]

## 2. Holdout Validation ##

from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import mean_squared_error

train_one = split_one
test_one = split_two
train_two = split_two
test_two = split_one

knn = KNeighborsRegressor(n_neighbors = 5)
knn.fit(train_one[['accommodates']], train_one['price'])
predict_one = knn.predict(test_one[['accommodates']])
mse = mean_squared_error(test_one['price'], predict_one)
iteration_one_rmse= mse ** 0.5

knn2 = KNeighborsRegressor(n_neighbors = 5)
knn2.fit(train_two[['accommodates']], train_two['price'])
predict_two = knn2.predict(test_two[['accommodates']])
mse = mean_squared_error(test_two['price'], predict_two)
iteration_two_rmse = mse ** 0.5

avg_rmse = numpy.mean([iteration_one_rmse, iteration_two_rmse])


## 3. K-Fold Cross Validation ##


dc_listings.set_value(dc_listings.index[0:744], 'fold', 1)
dc_listings.set_value(dc_listings.index[744:1488], 'fold', 2)
dc_listings.set_value(dc_listings.index[1488: 2232], 'fold', 3)
dc_listings.set_value(dc_listings.index[2232: 2976], 'fold', 4)
dc_listings.set_value(dc_listings.index[2976: 3723], 'fold', 5)

dc_listings['fold'].unique()

print(dc_listings.head())

## 4. First iteration ##

from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import mean_squared_error

train_1 = dc_listings[dc_listings['fold'] != 1]
test_1 = dc_listings[dc_listings['fold'] == 1]

knn = KNeighborsRegressor()
knn.fit(train_1[['accommodates']], train_1['price'])
predict_1 = knn.predict(test_1[['accommodates']])

mse_1 = mean_squared_error(test_1['price'], predict_1)

iteration_one_rmse = mse_1 ** 0.5

## 5. Function for training models ##

# Use np.mean to calculate the mean.
import numpy as np
fold_ids = [1,2,3,4,5]

def train_and_validate(df, folds):
    rmse_list = []
    for i in folds:
        train = dc_listings[dc_listings['fold'] != i]
        test = dc_listings[dc_listings['fold'] == i]
                           
        knn = KNeighborsRegressor()
        knn.fit(train[['accommodates']], train['price'])
        predictions = knn.predict(test[['accommodates']])
        
        mse = mean_squared_error(test['price'], predictions)
        rmse = mse ** 0.5
        
        rmse_list.append(rmse)
        
    return rmse_list
   
rmse_list = train_and_validate(dc_listings, fold_ids)

avg_rmse = numpy.mean(rmse_list)  

                           

## 6. Performing K-Fold Cross Validation Using Scikit-Learn ##

from sklearn.cross_validation import KFold
from sklearn.cross_validation import cross_val_score

kf = KFold(len(dc_listings), 5, shuffle = True, random_state = 1)
knn = KNeighborsRegressor()

mses = cross_val_score(knn, dc_listings[['accommodates']], dc_listings['price'], scoring = 'mean_squared_error', cv=kf)

avg_rmse = numpy.mean(numpy.abs(mses) ** 0.5) 