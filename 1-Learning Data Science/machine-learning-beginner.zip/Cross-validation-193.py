## 2. Holdout validation ##

import numpy as np
np.random.seed(8)
admissions = pd.read_csv("admissions.csv")
admissions["actual_label"] = admissions["admit"]
admissions = admissions.drop("admit", axis=1)

shuffled_index = np.random.permutation(admissions.index)
shuffled_admissions = admissions.loc[shuffled_index]

train = shuffled_admissions.iloc[0:515]
test = shuffled_admissions.iloc[515: len(shuffled_admissions)]
print(shuffled_admissions.head())



## 3. Accuracy ##

import numpy as np
np.random.seed(8)

shuffled_index = np.random.permutation(admissions.index)
shuffled_admissions = admissions.loc[shuffled_index]
train = shuffled_admissions.iloc[0:515]
test = shuffled_admissions.iloc[515:len(shuffled_admissions)]

model = LogisticRegression()
model.fit(train[["gpa"]], train['actual_label'])

test['predicted_label'] = model.predict(test[['gpa']])

matches = test[test['predicted_label'] == test['actual_label']]

accuracy = len(matches) / len(test)

print(accuracy)

## 4. Sensitivity and specificity ##

model = LogisticRegression()
model.fit(train[["gpa"]], train["actual_label"])
labels = model.predict(test[["gpa"]])
test["predicted_label"] = labels
matches = test["predicted_label"] == test["actual_label"]
correct_predictions = test[matches]
accuracy = len(correct_predictions) / len(test)

# Sensitivity meassures the ones that got into pr should have got into.
true_positives = test[(test['predicted_label'] ==1) & (test['actual_label'] == 1)]
false_negatives = test[(test['predicted_label'] ==0) & (test['actual_label'] == 1)]

sensitivity = len(true_positives) / (len(true_positives) + len(false_negatives))

# Specificity meassures the ones that didnt enter.
false_positives = test[(test['predicted_label'] == 1) & (test['actual_label'] == 0)]
true_negatives = test[(test['predicted_label'] == 0) & (test['actual_label'] == 0)]

specificity = len(true_negatives) / (len(true_negatives) + len(false_positives))

## 6. ROC curve ##

import matplotlib.pyplot as plt
from sklearn import metrics

probabilities = model.predict_proba(test[['gpa']])

fpr, tpr, thresholds = metrics.roc_curve(test['actual_label'], probabilities[:,1])

plt.plot(fpr, tpr)
plt.show()

## 7. Area under the curve ##

# Note the different import style!
from sklearn.metrics import roc_auc_score

auc_score = roc_auc_score(test['actual_label'], probabilities[:, 1])