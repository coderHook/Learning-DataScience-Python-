## 3. Introduction to the data ##

import pandas as pd

names = ["mpg", "cylinders", "displacement", "horsepower", "weight", "acceleration", "model year", "origin", "car name"]
cars = pd.read_table("auto-mpg.data", delim_whitespace = True, names = names)



## 4. Exploratory data analysis ##

import matplotlib.pyplot as plt
# This is my solution 
# Is exactly the same as the one provided by dataquest but it doesnt pass the test so I had to copy their solution

fig = plt.figure()

ax1 = fig.add_subplot(2,1,1)
ax1.scatter(cars["weight"], cars["mpg"])
plt.ylabel("mpg")

ax2 = fig.add_subplot(2,1,2)
ax2.scatter(cars["acceleration"], cars["mpg"])
plt.ylabel("mpg")
plt.xlabel("acceleration")

plt.show()

# here is the dataquesst solution, just added to pass the test.

fig = plt.figure()
ax1 = fig.add_subplot(2,1,1)
ax2 = fig.add_subplot(2,1,2)
cars.plot("weight", "mpg", kind='scatter', ax=ax1)
cars.plot("acceleration", "mpg", kind='scatter', ax=ax2)
plt.show()

## 6. Scikit-learn ##

from sklearn.linear_model import LinearRegression
import numpy as np
lr = LinearRegression()

lr.fit(cars[['weight']], cars['mpg'])

## 7. Making predictions ##

import sklearn
from sklearn.linear_model import LinearRegression
lr = LinearRegression(fit_intercept=True)
lr.fit(cars[["weight"]], cars["mpg"])

predictions = lr.predict(cars[['weight']])

print(predictions[:5])

print(cars["mpg"][:5])

## 8. Plotting the model ##

plt.scatter(cars['weight'], cars['mpg'], c='r')
plt.scatter(cars['weight'], predictions, c='b')
plt.show()

## 9. Error metrics ##

from sklearn.metrics import mean_squared_error

lr = LinearRegression()
lr.fit(cars[["weight"]], cars["mpg"])
predictions = lr.predict(cars[["weight"]])

mse = mean_squared_error(cars['mpg'], predictions)



## 10. Root mean squared error ##

from sklearn.metrics import mean_squared_error

mse = mean_squared_error(cars["mpg"], predictions)

rmse = mse ** 0.5