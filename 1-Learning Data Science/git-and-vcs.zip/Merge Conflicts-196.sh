## 1. Introduction ##

/home/dq/chatbot$ git merge feature/queen-bot master

## 2. Aborting a Merge ##

/home/dq/chatbot$ git merge --abort

## 3. Resolving Conflicts ##

/home/dq/chatbot$ git push origin master

## 4. Resolving Multi-Line Conflicts ##

/home/dq/chatbot$ git push origin master

## 5. Resolving Multiple Conflicts ##

/home/dq/chatbot$ git push origin master

## 6. Accepting Changes From Only One Branch ##

/home/dq/chatbot$ git push origin master

## 7. Ignoring Files ##

/home/dq/chatbot$ git push origin master

## 8. Removing Cached Files ##

/home/dq/chatbot$ git push origin master