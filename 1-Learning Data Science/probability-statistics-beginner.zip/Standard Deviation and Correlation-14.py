## 2. The Mean as the Center ##

# Make a list of values
values = [2, 4, 5, -1, 0, 10, 8, 9]
# Compute the mean of the values
values_mean = sum(values) / len(values)
# Find the difference between each of the values and the mean by subtracting the mean from each value.
differences = [i - values_mean for i in values]
# This equals 0.  If you'd like, try changing the values around to verify that it still equals 0.
print(differences)
print(sum(differences))

# We can use the median function from numpy to find the median.
# The median is the "middle" value in a set of values. If we sort the values in order, it's the one in the center (or the average of the two in the center if there are an even number of items in the set).
# You'll see that the differences from the median don't always add up to 0.  You might want to play around with this and think about why that is.
from numpy import median

values_median = median(values)
print(values_median)

median_difference_sum = [i - values_median for i in values]


## 3. Finding Variance ##

# You may be wondering why multiplication and division are on the same level.
# It doesn't matter whether we do the multiplication or division first; the answer here will always be the same.
# In this case, we need to think of division as multiplication by a fraction. Otherwise, we'll be dividing more than we want to.
# Create a formula
a = 5 * 5 / 2
# Multiply by 1/2 instead of dividing by 2. The result is the same (2/2 == 2 * 1/2).
a_subbed = 5 * 5 * 1/2
a_mul_first = 25 * 1/2
a_div_first = 5 * 2.5
print(a_mul_first == a_div_first)

# The same is true for subtraction and addition.
# In this case, we need to convert subtraction into adding a negative number. If we don't we'll end up subtracting more than we expect.
b = 10 - 8 + 5
# Add -8 instead of subtracting 8.
b_subbed = 10 + -8 + 5
b_sub_first = 2 + 5
b_add_first = 10 + -3
print(b_sub_first == b_add_first)

c = 10 * 5 / 2
d = (3 - 1) / (2 * 2)

## 4. Understanding the Order of Operations ##

# You may be wondering why multiplication and division are on the same level.
# It doesn't matter whether we do the multiplication or division first; the answer here will always be the same.
# In this case, we need to think of division as multiplication by a fraction. Otherwise, we'll be dividing more than we want to.
# Create a formula
a = 5 * 5 / 2
# Multiply by 1/2 instead of dividing by 2. The result is the same (2/2 == 2 * 1/2).
a_subbed = 5 * 5 * 1/2
a_mul_first = 25 * 1/2
a_div_first = 5 * 2.5
print(a_mul_first == a_div_first)

# The same is true for subtraction and addition.
# In this case, we need to convert subtraction into adding a negative number. If we don't we'll end up subtracting more than we expect.
b = 10 - 8 + 5
# Add -8 instead of subtracting 8.
b_subbed = 10 + -8 + 5
b_sub_first = 2 + 5
b_add_first = 10 + -3
print(b_sub_first == b_add_first)

c = 10 * 5 / 2
d = (3 - 1) / (2 * 2)

## 5. Using Parentheses to Change the Order of Operations ##

a = 50 * 50 - 10 / 5
a_paren = 50 * (50 - 10) / 5
# If we put multiple operations inside parentheses, the interpreter will use the order of operations to determine the sequence in which it should execute them.
a_paren = 50 * (50 - 10 / 5)

b = 10 * (10 + 100)
c = (8 - 6) * 100

## 6. Fractional Powers ##

a = 5 ** 2
# Raise to the fourth power
b = 10 ** 4

# Take the square root ( 3 * 3 == 9, so the answer is 3)
c = 9 ** (1/2)

# Take the cube root (4 * 4 * 4 == 64, so 4 is the cube root)
d = 64 ** (1/3)

e = 11 ** 5
f = 10000 ** (1/4)

## 7. Calculating Standard Deviation ##

# You may be wondering why multiplication and division are on the same level.
# It doesn't matter whether we do the multiplication or division first; the answer here will always be the same.
# In this case, we need to think of division as multiplication by a fraction. Otherwise, we'll be dividing more than we want to.
# Create a formula
a = 5 * 5 / 2
# Multiply by 1/2 instead of dividing by 2. The result is the same (2/2 == 2 * 1/2).
a_subbed = 5 * 5 * 1/2
a_mul_first = 25 * 1/2
a_div_first = 5 * 2.5
print(a_mul_first == a_div_first)

# The same is true for subtraction and addition.
# In this case, we need to convert subtraction into adding a negative number. If we don't we'll end up subtracting more than we expect.
b = 10 - 8 + 5
# Add -8 instead of subtracting 8.
b_subbed = 10 + -8 + 5
b_sub_first = 2 + 5
b_add_first = 10 + -3
print(b_sub_first == b_add_first)

c = 10 * 5 / 2
d = (3 - 1) / (2 * 2)

## 8. Finding Standard Deviation Distance ##

import numpy as np
import matplotlib.pyplot as plt
# The norm module has a pdf function (pdf stands for probability density function)
from scipy.stats import norm

# The arange function generates a numpy vector
# The vector below will start at -1, and go up to, but not including 1
# It will proceed in "steps" of .01.  So the first element will be -1, the second -.99, the third -.98, all the way up to .99.
points = np.arange(-1, 1, 0.01)

# The norm.pdf function will take the points vector and convert it into a probability vector
# Each element in the vector will correspond to the normal distribution (earlier elements and later element smaller, peak in the center)
# The distribution will be centered on 0, and will have a standard devation of .3
probabilities = norm.pdf(points, 0, .3)

# Plot the points values on the x-axis and the corresponding probabilities on the y-axis
# See the bell curve?
plt.plot(points, probabilities)
plt.show()

# Lets make another normalization of the probability distribution function.
points2 = np.arange(-10, 10, 0.1)
probabilities2 = norm.pdf(points, 0, 2)

plt.plot(points2, probabilities2)
plt.show()

## 9. Working with the Normal Distribution ##

# We've already loaded the NBA stats into the nba_stats variable.

def calc_dev(data):
    data_mean = data.mean()
    dev = 0
    for d in data:
        diff = d - data_mean
        sqr_data = diff ** 2
        dev += sqr_data
       
    dev = (dev/len(data)) ** (1/2)
    return dev

mp_dev = calc_dev(nba_stats["mp"])
ast_dev = calc_dev(nba_stats["ast"])

## 10. Normal Distribution Deviation ##

import numpy as np

# Housefly wing lengths in millimeters
wing_lengths = [36, 37, 38, 38, 39, 39, 40, 40, 40, 40, 41, 41, 41, 41, 41, 41, 42, 42, 42, 42, 42, 42, 42, 43, 43, 43, 43, 43, 43, 43, 43, 44, 44, 44, 44, 44, 44, 44, 44, 44, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 47, 47, 47, 47, 47, 47, 47, 47, 47, 48, 48, 48, 48, 48, 48, 48, 48, 49, 49, 49, 49, 49, 49, 49, 50, 50, 50, 50, 50, 50, 51, 51, 51, 51, 52, 52, 53, 53, 54, 55]

mean = np.mean(wing_lengths)
variance = [(i - mean) ** 2  for i in wing_lengths]

variance = sum(variance) / len(variance)

std_dev = variance ** (1/2)

distance_for_each = [(p - mean)/std_dev for p in wing_lengths]

within_one = [ n for n in distance_for_each if (n >= -1) & (n <= 1)]
within_one_percentage = (len(within_one)/len(distance_for_each))

def within_n(rang):
    within = [n for n in distance_for_each if(n >= -1*rang) & (n <= rang)]
    within_percentage = len(within)/len(distance_for_each)
    
    return within_percentage

within_two_percentage = within_n(2)
within_three_percentage = within_n(3)

## 11. Using Scatterplots to Plot Correlations ##

import matplotlib.pyplot as plt

# Plot field goals attempted (number of shots someone takes in a season) vs. point scored in a season.
# Field goals attempted is on the x-axis, and points is on the y-axis.
# As you can tell, they are very strongly correlated. The plot is close to a straight line.
# The plot also slopes upward, which means that as field goal attempts go up, so do points.
# That means that the plot is positively correlated.
plt.scatter(nba_stats["fga"], nba_stats["pts"])
plt.show()

# If we make points negative (so the people who scored the most points now score the least, because 3000 becomes -3000), we can change the direction of the correlation.
# Field goals are negatively correlated with our new "negative" points column -- the more free throws you attempt, the less negative points you score.
# We can see this because the correlation line slopes downward.
plt.scatter(nba_stats["fga"], -nba_stats["pts"])
plt.show()

# Now, we can plot total rebounds (number of times someone got the ball back for their team after someone shot) vs total assists (number of times someone helped another person score).
# These are uncorrelated, so you don't see the same nice line as you see with the plot above.
plt.scatter(nba_stats["trb"], nba_stats["ast"])
plt.show()

# Scatter of the "fta" and "pts"
plt.scatter(nba_stats["fta"], nba_stats["pts"])
plt.show()

# Scatter of the "stl" and "pf"
plt.scatter(nba_stats["stl"], nba_stats["pf"])
plt.show()
 
                
              

## 12. Measuring Correlation with Pearson's r ##

from scipy.stats.stats import pearsonr

# The pearsonr function will find the correlation between two columns of data.
# It returns the r value and the p value.  We'll learn more about p values later on.
r, p_value = pearsonr(nba_stats["fga"], nba_stats["pts"])
# As we can see, this is a very high positive r value - it's close to 1.
print(r)

# These two columns are much less correlated.
r, p_value = pearsonr(nba_stats["trb"], nba_stats["ast"])
# We get a much lower, but still positive, r value.
print(r)

r_fta_pts, p_fta_value= pearsonr(nba_stats["fta"], nba_stats["pts"])
print(r_fta_pts)

r_stl_pf, p_stl_value = pearsonr(nba_stats["stl"], nba_stats["pf"])
print(r_stl_pf)

## 13. Calculate Covariance ##

# We've already loaded the nba_stats variable.

def calc_cov(x, y):
    x_mean = x.mean()
    y_mean = y.mean()
    
    x_diff = [ nx - x_mean for nx in x]
    y_diff = [ ny - y_mean for ny in y]
    
    mult = [ x_diff[i] * y_diff[i] for i in range(0, len(x))]
    
    cov = sum(mult) / len(x)
    
    return cov

cov_stl_pf = calc_cov(nba_stats["stl"], nba_stats["pf"])
cov_fta_pts = calc_cov(nba_stats["fta"], nba_stats["pts"])

## 14. Calculate Correlation With the std() Method ##

from numpy import cov
# We've already loaded the nba_stats variable for you.

r_fta_blk = cov(nba_stats["fta"], nba_stats["blk"])[0, 1] / (nba_stats["fta"].std() * nba_stats["blk"].std())

r_ast_stl = cov(nba_stats["ast"], nba_stats["stl"])[0,1] / ( nba_stats["ast"].std() * nba_stats["stl"].std())