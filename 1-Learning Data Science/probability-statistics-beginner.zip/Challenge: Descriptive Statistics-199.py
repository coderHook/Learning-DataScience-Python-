## 1. Introduction ##

import matplotlib.pyplot as plt
import pandas as pd
movie_reviews = pd.read_csv("fandango_score_comparison.csv")

scores = ["RT_user_norm", "Metacritic_user_nom", "Fandango_Ratingvalue", "IMDB_norm"]

fig = plt.figure(figsize=(5, 12))
for i, sc in enumerate(scores):
    fig.add_subplot(4, 1, i+1)
    ax = movie_reviews[sc].plot(kind='hist')
    ax.set_xlim([0, 5])
    ax.set_ylabel('')
    ax.grid()
   
plt.show()

## 2. Mean ##

def calc_mean(data):
    mean = data.mean()
    return mean

sel_cols = ['RT_user_norm', 'Metacritic_user_nom', 'Fandango_Ratingvalue', 'IMDB_norm']

user_review = movie_reviews[sel_cols]

rt_mean, mc_mean, fg_mean, id_mean = user_review.apply(calc_mean)

## 3. Variance and standard deviation ##

def calc_mean(series):
    vals = series.values
    mean = sum(vals) / len(vals)
    return mean

def calc_variance(series):
    mean = calc_mean(series)
    variance = [ (x - mean) **2 for x in series]
    variance = sum(variance) / len(variance)
    return variance

def calc_stdev(series):
    variance = calc_variance(series)
    return variance ** (1/2)

rt_var, mc_var, fg_var, id_var = user_reviews.apply(calc_variance)
rt_stdev, mc_stdev, fg_stdev, id_stdev = user_reviews.apply(calc_stdev)

## 4. Scatter plots ##

import matplotlib.pyplot as plt
fig = plt.figure(figsize = (4, 8))
scores = ["RT_user_norm", "Metacritic_user_nom", "IMDB_norm", "Fandango_Ratingvalue"]
for i in range(0,3):
    fig.add_subplot(3, 1, i+1)
    ax = plt.scatter(movie_reviews[scores[i]], movie_reviews[scores[3]])    
    plt.xlim(0.0, 5.0)
    
plt.show()

## 5. Covariance ##

def calc_mean(series):
    vals = series.values
    mean = sum(vals) / len(vals)
    return mean

def calc_covariance(x, y):
    x_mean = calc_mean(x)
    y_mean = calc_mean(y)
    
    x_diff = [nx - x_mean for nx in x]
    y_diff = [ny - y_mean for ny in y]
    
    xy_mult = [ (x_diff[i] * y_diff[i]) for i in range(0,len(x_diff))]
    
    covariance = sum(xy_mult) / len(x)
    
    return covariance

scores = ["RT_user_norm", "Metacritic_user_nom", "IMDB_norm", "Fandango_Ratingvalue"]

rt_fg_covar = calc_covariance(movie_reviews[scores[0]], movie_reviews[scores[3]]) 
mc_fg_covar = calc_covariance(movie_reviews[scores[1]], movie_reviews[scores[3]]) 
id_fg_covar = calc_covariance(movie_reviews[scores[2]], movie_reviews[scores[3]])

## 6. Correlation ##

def calc_mean(series):
    vals = series.values
    mean = sum(vals) / len(vals)
    return mean

def calc_variance(series):
    mean = calc_mean(series)
    squared_deviations = (series - mean)**2
    mean_squared_deviations = calc_mean(squared_deviations)
    return mean_squared_deviations

def calc_covariance(series_one, series_two):
    x = series_one.values
    y = series_two.values
    x_mean = calc_mean(series_one)
    y_mean = calc_mean(series_two)
    x_diffs = [i - x_mean for i in x]
    y_diffs = [i - y_mean for i in y]
    codeviates = [x_diffs[i] * y_diffs[i] for i in range(len(x))]
    return sum(codeviates) / len(codeviates)

rt_fg_covar = calc_covariance(movie_reviews["RT_user_norm"], movie_reviews["Fandango_Ratingvalue"])
mc_fg_covar = calc_covariance(movie_reviews["Metacritic_user_nom"], movie_reviews["Fandango_Ratingvalue"])
id_fg_covar = calc_covariance(movie_reviews["IMDB_norm"], movie_reviews["Fandango_Ratingvalue"])

def calc_correlation(x, y):
    covariance = calc_covariance(x, y)
    correlation = covariance / ((calc_variance(x) ** (1/2)) * (calc_variance(y) ** (1/2)))
    
    return correlation


rt_fg_corr = calc_correlation(movie_reviews["RT_user_norm"], movie_reviews["Fandango_Ratingvalue"])
mc_fg_corr = calc_correlation(movie_reviews["Metacritic_user_nom"], movie_reviews["Fandango_Ratingvalue"])
id_fg_corr = calc_correlation(movie_reviews["IMDB_norm"], movie_reviews["Fandango_Ratingvalue"])

## 7. Next steps ##

import matplotlib.pyplot as plt
import pandas as pd
movie_reviews = pd.read_csv("fandango_score_comparison.csv")

scores = ["RT_user_norm", "Metacritic_user_nom", "Fandango_Ratingvalue", "IMDB_norm"]

fig = plt.figure(figsize=(5, 12))
for i, sc in enumerate(scores):
    fig.add_subplot(4, 1, i+1)
    ax = movie_reviews[sc].plot(kind='hist')
    ax.set_xlim([0, 5])
    ax.set_ylabel('')
    ax.grid()
   
plt.show()