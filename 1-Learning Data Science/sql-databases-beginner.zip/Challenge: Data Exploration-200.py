## 1. Introduction ##

import sqlite3
conn = sqlite3.connect("factbook.db")
cursor = conn.cursor()

q_pop_avg = "select AVG(population) as pop_avg, from facts;"
pop_avg = cursor.execute(q_avg).fetchone()

q_pop_growth = "select avg(population_growth) as pop_growth_avg from facts;"
pop_growth_avg = cursor.execute(q_pop_growth).fetchone()

## 2. Find Ranges ##

conn = sqlite3.connect("factbook.db")

averages = "select avg(population), avg(population_growth), avg(birth_rate), avg(death_rate), avg(migration_rate) from facts;"
avg_results = conn.execute(averages).fetchall()
pop_avg = avg_results[0][0]
pop_growth_avg = avg_results[0][1]
birth_rate_avg = avg_results[0][2]
death_rate_avg = avg_results[0][3]
mig_rate_avg = avg_results[0][4]

min_max_q = "select min(population), max(population), min(population_growth), max(population_growth), min(birth_rate), max(birth_rate), min(death_rate), max(death_rate) from facts;"
min_max_results = conn.execute(min_max_q).fetchall()

pop_min = min_max_results[0][0]
pop_max = min_max_results[0][1]
pop_growth_min = min_max_results[0][2]
pop_growth_max = min_max_results[0][3]
birth_rate_min = min_max_results[0][4]
birth_rate_max = min_max_results[0][5]
death_rate_min = min_max_results[0][6]
death_rate_max = min_max_results[0][7]

## 3. Filter Values ##

conn = sqlite3.connect("factbook.db")

min_max_q = "select min(population), max(population), min(population_growth), max(population_growth), min(birth_rate), max(birth_rate), min(death_rate), max(death_rate) from facts where (population < 2000000000) and (population > 0);"
min_max_results = conn.execute(min_max_q).fetchall()

pop_min = min_max_results[0][0]
pop_max = min_max_results[0][1]
pop_growth_min = min_max_results[0][2]
pop_growth_max = min_max_results[0][3]
birth_rate_min = min_max_results[0][4]
birth_rate_max = min_max_results[0][5]
death_rate_min = min_max_results[0][6]
death_rate_max = min_max_results[0][7]


## 4. Predict Future Population Growth ##

import sqlite3
conn = sqlite3.connect("factbook.db")

q_pop = "select ROUND(population + (population * (population_growth/100)), 0) from facts where (population IS NOT NULL AND population_growth IS NOT NULL) AND (population < 7000000000 AND population > 0);"

projected_population = conn.execute(q_pop).fetchall()

## 5. Explore Projected Population ##

import sqlite3
conn = sqlite3.connect("factbook.db")

query = "select ROUND(min(population + (population * (population_growth/100))), 0), ROUND(max(population + (population * (population_growth/100))), 0), ROUND(avg(population + (population * (population_growth/100))), 0) from facts where (population IS NOT NULL AND population_growth IS NOT NULL) AND (population < 7000000000 AND population > 0);"
results = conn.execute(query).fetchall()

pop_proj_min = results[0][0]
pop_proj_max = results[0][1]
pop_proj_avg = results[0][2]
