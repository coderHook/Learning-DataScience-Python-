## 3. Psycopg2 ##

import psycopg2

conn = psycopg2.connect("dbname=dq user=dq")
cursor = conn.cursor()

print(cursor)

conn.close()

## 4. Creating a table ##

query = '''CREATE TABLE notes (
    id INTEGER primary key,
    body text,
    title text
);'''



## 5. SQL Transactions ##

conn = psycopg2.connect('dbname = dq user = dq')
cur = conn.cursor()
cur.execute("DROP TABLE notes;")
cur.execute("CREATE TABLE notes(id integer PRIMARY KEY, body text, title text);")
conn.commit()
conn.close()


## 6. Autocommitting ##

conn = psycopg2.connect("dbname=dq user=dq")
conn.autocommit = True
cur = conn.cursor()
#cur.execute("DROP TABLE notes")
cur.execute("CREATE TABLE facts(id integer PRIMARY KEY, country text, value text)")
conn.close()

## 7. Executing queries ##

conn = psycopg2.connect("dbname=dq user=dq")
cur = conn.cursor()
cur.execute("INSERT INTO notes VALUES (1, 'Do more missions on Dataquest.', 'Dataquest reminder');")
cur.execute("SELECT * from notes;")
rows = cur.fetchall()
print(rows)

miss_cache = True

conn.close()

## 8. Creating a database ##

import psycopg2

conn= psycopg2.connect("dbname=dq user=dq")
cur = conn.cursor()

conn.autocommit = True
miss_cache = True

cur.execute("CREATE DATABASE income OWNER dq;")

conn.close()

## 9. Deleting a database ##

import psycopg2

conn= psycopg2.connect("dbname=dq user=dq")
cur = conn.cursor()

conn.autocommit = True

cur.execute("DROP DATABASE income;")

conn.close()