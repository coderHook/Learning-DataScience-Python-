## 4. Querying a normalized database ##

query = "select ceremonies.year, nominations.movie FROM nominations INNER JOIN ceremonies ON nominations.ceremony_id == ceremonies.id WHERE nominations.nominee == 'Natalie Portman';"
portman_movies = conn.execute(query).fetchall()

## 7. Join table ##

query_join = "select * from movies_actors LIMIT 5;"
five_join_table = conn.execute(query_join).fetchall()

query_actors = "select * from actors LIMIT 5;"
five_actors = conn.execute(query_actors).fetchall()

query_movies = "select * from movies LIMIT 5;"
five_movies = conn.execute(query_movies).fetchall()

## 9. Querying a many-to-many relation ##

query = '''
SELECT actors.actor, movies.movie FROM movies 
INNER JOIN movies_actors ON movies.id == movies_actors.movie_id
INNER JOIN actors ON movies_actors.actor_id == actors.id
WHERE movies.movie == "The King's Speech";
'''
kings_actors = conn.execute(query).fetchall()
print(kings_actors)

## 10. Practice: querying a many-to-many relation ##

q = '''
SELECT movies.movie, actors.actor FROM movies
INNER JOIN movies_actors ON movies.id == movies_actors.movie_id
INNER JOIN actors ON  movies_actors.actor_id == actors.id
WHERE actors.actor == "Natalie Portman";'''

portman_joins = conn.execute(q).fetchall()
print(portman_joins)