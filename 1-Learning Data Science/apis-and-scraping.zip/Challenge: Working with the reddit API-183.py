## 2. Authenticating with the API ##

headers = {"Authorization": "bearer 13426216-4U1ckno9J5AiK72VRbpEeBaMSKk", "User-Agent": "Dataquest/1.0"}

params = {'t':"day"}

response = requests.get("https://oauth.reddit.com/r/python/top", headers=headers, params=params)

python_top = response.json()



## 3. Getting the Most Upvoted Post ##

most_upvoted = python_top['data']['children'][0]['data']['selftext']

python_top_articles = []

#we initialized the most_upvoted with the first one in order to compare it with the rest.

most_ups = python_top['data']['children'][0]['data']['ups']
most_upvoted = python_top['data']['children'][0]['data']['id']
for n in python_top['data']['children']:
    
    python_top_articles.append(n['data']['selftext'])
    
    if most_ups < n['data']['ups']:
        most_upvoted = n['data']['id']
        most_ups = n['data']['ups']

## 4. Getting Post Comments ##

response = requests.get("https://oauth.reddit.com/r/python/comments/4b7w9u", headers=headers)

comments = response.json()

## 5. Getting the Most Upvoted Comment ##

# This help_com is just a variable I created to look for in the comments chains.
help_com = comments[1]['data']['children'][0]['data']['body']

# Comments has two chains 0 for the main post and 1 for the comments.
replies_chain = comments[1]['data']['children']
comments_list = []

# Initialize most_upvoted_commenets with the first one, and from it we will check if there is any that has more 'ups'. Same for the variable upvotes.
most_upvoted_comment = replies_chain[0]['data']['id']
upvotes = replies_chain[0]['data']['ups']

for n in replies_chain:
    comments_list.append(n['data']['body'])
    
    if upvotes < n['data']['ups']:
        upvotes = n['data']['ups']
        most_upvoted_comment = n['data']['id']

## 6. Upvoting a Comment ##

# most_upvoted_comment = d16y4ry

payload = {'dir': 1, 'id': 'd16y4ry'}

response = requests.post("https://oauth.reddit.com/api/vote", headers=headers, json=payload)

status = response.status_code