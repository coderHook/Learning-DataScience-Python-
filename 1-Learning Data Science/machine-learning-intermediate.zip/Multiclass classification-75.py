## 1. Introduction to the data ##

import pandas as pd
cars = pd.read_csv("auto.csv")

unique_regions = cars['origin'].unique()

## 2. Dummy variables ##

dummy_cylinders = pd.get_dummies(cars["cylinders"], prefix="cyl")
cars = pd.concat([cars, dummy_cylinders], axis=1)

dummy_years = pd.get_dummies(cars['year'], prefix = "year")
cars = pd.concat([cars, dummy_years], axis = 1)

cars = cars.drop(['cylinders', 'year'], axis = 1)

print(cars.head())

## 3. Multiclass classification ##

shuffled_rows = np.random.permutation(cars.index)
shuffled_cars = cars.iloc[shuffled_rows]

limit_1 = round(len(cars)*0.70)

print(len(cars))

train = shuffled_cars.iloc[0: limit_1]
test = shuffled_cars.iloc[limit_1: len(cars)]

print(train.head())

## 4. Training a multiclass logistic regression model ##

from sklearn.linear_model import LogisticRegression

unique_origins = cars["origin"].unique()
unique_origins.sort()

models = {}

num_data = [q for q in train.columns if (q.startswith('cyl')) or (q.startswith('year'))]

for i in unique_origins:
    logit = LogisticRegression()
    
    x_train = train[num_data]
    y_train = train['origin'] == i
    
    logit.fit(x_train, y_train)
        
    models[i] = logit
 
print(models)
        

## 5. Testing the models ##

testing_probs = pd.DataFrame(columns=unique_origins)

for i in unique_origins:
    x_test = test[num_data]
    testing_probs[i] = models[i].predict_proba(x_test)[:,1]
    

## 6. Choose the origin ##

predicted_origins = testing_probs.idxmax(axis=1)